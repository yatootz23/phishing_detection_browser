import sqlite3

database = r"C:\Users\nellen\Desktop\Python\Django\web_browser\website\db.sqlite3"
try:
    conn = sqlite3.connect(database)
except Error as e:
    print(e)
cursor = conn.cursor()
cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
print(cursor. fetchall())