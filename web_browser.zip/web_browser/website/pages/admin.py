from django.contrib import admin
from .models import History, CurrentUser
# Register your models here.


admin.site.register(History)
admin.site.register(CurrentUser)