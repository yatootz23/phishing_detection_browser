from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from .forms import CreateUserForm, HistoryForm, CurrentUserForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import History, CurrentUser
from datetime import datetime, timedelta
# Create your views here.


def index(request):
    if request.user.is_authenticated:
        return redirect('profile')
    else:
        return render(request, 'pages/index.html')

def info(request):
        return render(request, 'pages/info.html')

def registerPage(request):
    if request.user.is_authenticated:
        return redirect('profile')
    else:    
        form = CreateUserForm()
        if request.method == 'POST':
            form = CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                messages.success(request, 'Account created!')
                return redirect('login')
        context = {
            'form': form
        }
        return render(request, 'pages/register.html', context)


def loginPage(request):
    if request.user.is_authenticated:
        return redirect('profile')
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')
            print(username, password)
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                form = CurrentUser(user=user)
                form.save()
                return redirect('profile')
            else:
                messages.info(request, 'Username/Password is incorrect')
        return render(request, 'pages/login.html')


def logoutUser(request):
    logout(request)
    return redirect('login')

@login_required(login_url='login')
def profile(request):
    last_month = datetime.today() - timedelta(30)
    last_week = datetime.today() - timedelta(7)
    last_24hrs = datetime.today() - timedelta(1)
    
    recent_history = History.objects.filter(user=request.user).order_by('-date_accessed')[:5]
    history_all = History.objects.filter(user=request.user)
    history_legit = History.objects.filter(user=request.user, is_phishing=0)
    history_phish = History.objects.filter(user=request.user, is_phishing=1)
    history_legit_count = history_legit.count()
    history_phish_count = history_phish.count() 
    legit_percent = round((history_legit.count() / history_all.count()) *100)
    phish_percent = round((history_phish.count() / history_all.count()) *100)
    
    history_all_today = History.objects.filter(user=request.user, date_accessed__gt=last_24hrs)
    history_legit_today = History.objects.filter(user=request.user, date_accessed__gt=last_24hrs, is_phishing=0)
    history_phish_today = History.objects.filter(user=request.user, date_accessed__gt=last_24hrs, is_phishing=1)
    today_counter = history_all_today.count()
    if today_counter == 0:
        today_counter = 1
    history_legit_today_count = history_legit_today.count()
    history_phish_today_count = history_phish_today.count() 
    legit_percent_today = round((history_legit_today.count() / today_counter) *100)
    phish_percent_today = round((history_phish_today.count() / today_counter) *100)
    
    history_all_week = History.objects.filter(user=request.user, date_accessed__gt=last_week)
    history_legit_week = History.objects.filter(user=request.user, date_accessed__gt=last_week, is_phishing=0)
    history_phish_week = History.objects.filter(user=request.user, date_accessed__gt=last_week, is_phishing=1)
    week_counter = history_all_week.count()
    if week_counter == 0:
        week_counter = 1
    history_legit_week_count = history_legit_week.count()
    history_phish_week_count = history_phish_week.count() 
    legit_percent_week = round((history_legit_week.count() / week_counter) *100)
    phish_percent_week = round((history_phish_week.count() / week_counter) *100)

    history_all_month = History.objects.filter(user=request.user, date_accessed__gt=last_month)
    history_legit_month = History.objects.filter(user=request.user, date_accessed__gt=last_month, is_phishing=0)
    history_phish_month = History.objects.filter(user=request.user, date_accessed__gt=last_month, is_phishing=1)
    month_counter = history_all_month.count()
    if month_counter == 0:
        month_counter = 1
    history_legit_month_count = history_legit_month.count()
    history_phish_month_count = history_phish_month.count() 
    legit_percent_month = round((history_legit_month.count() / month_counter) *100)
    phish_percent_month = round((history_phish_month.count() / month_counter) *100)
    
    context = {
        'recent_history': recent_history,
        'legit_percent': legit_percent,
        'phish_percent': phish_percent,
        'legit_percent_today': legit_percent_today,
        'phish_percent_today': phish_percent_today,
        'legit_percent_week': legit_percent_week,
        'phish_percent_week': phish_percent_week,
        'legit_percent_month': legit_percent_month,
        'phish_percent_month': phish_percent_month,
        'history_legit': history_legit_count,
        'history_phish': history_phish_count,
        'history_legit_today': history_legit_today_count,
        'history_phish_today': history_phish_today_count,
        'history_legit_week': history_legit_week_count,
        'history_phish_week': history_phish_week_count,
        'history_legit_month': history_legit_month_count,
        'history_phish_month': history_phish_month_count,
    }
    return render(request, 'pages/profile.html', context)

@login_required(login_url='login')
def checkHistory(request):
    history = History.objects.filter(user=request.user.id).order_by('-date_accessed')
    context = {
        'history': history,
    }
    return render(request, 'pages/history.html', context)


@login_required(login_url='login')
def phishingDetected(request):
    return render(request, 'pages/phishing_detected.html')