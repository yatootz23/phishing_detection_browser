from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from .forms import CreateUserForm, HistoryForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import History
# Create your views here.


def index(request):
    if request.user.is_authenticated:
        return redirect('profile')
    else:
        return render(request, 'pages/index.html')


def registerPage(request):
    if request.user.is_authenticated:
        return redirect('profile')
    else:    
        form = CreateUserForm()
        if request.method == 'POST':
            form = CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                messages.success(request, 'Account created!')
                return redirect('login')
        context = {
            'form': form
        }
        return render(request, 'pages/register.html', context)


def loginPage(request):
    if request.user.is_authenticated:
        return redirect('profile')
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')
            print(username, password)
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('profile')
            else:
                messages.info(request, 'Username/Password is incorrect')
        return render(request, 'pages/login.html')


def logoutUser(request):
    logout(request)
    return redirect('login')

@login_required(login_url='login')
def profile(request):
    history = History.objects.filter(user=request.user.id).order_by('-date_accessed')[:5]
    history_all = History.objects.filter(user=request.user.id)
    history_legit = History.objects.filter(user=request.user.id, is_phishing=0)
    history_phish = History.objects.filter(user=request.user.id, is_phishing=1)
    legit_percent = round((history_legit.count() / history_all.count()) *100)
    phish_percent = round((history_phish.count() / history_all.count()) *100)
    context = {
        'history': history,
        'legit_percent': legit_percent,
        'phish_percent': phish_percent,
    }
    return render(request, 'pages/profile.html', context)

@login_required(login_url='login')
def checkHistory(request):
    history = History.objects.filter(user=request.user.id).order_by('-date_accessed')
    context = {
        'history': history,
    }
    return render(request, 'pages/history.html', context)


def updateHistory(link, is_phishing):
    form = HistoryForm()
    form.user = request.user
    form.url = link
    form.is_phishing = is_phishing
    form.save()


@login_required(login_url='login')
def phishingDetected(request, link):
    form = HistoryForm()
    form.user = request.user
    form.url = link
    form.is_phishing = 1
    form.save()
    return render(request, 'pages/phishing_detected.html')