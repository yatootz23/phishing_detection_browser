from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name="index"),
    path('register/', views.registerPage, name="register"),
    path('login/', views.loginPage, name="login"),
    path('logout/', views.logoutUser, name="logout"),
    path('profile/', views.profile, name="profile"),
    path('history/', views.checkHistory, name="history"),
    path('phishing_detected/', views.phishingDetected, name="phishing"),
    path('info/', views.info, name="info"),
]
